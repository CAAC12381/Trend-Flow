import { PieChart, BarChart3, Users, Globe, Calendar, Download } from 'lucide-react';
import { PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, Tooltip, RadarChart, PolarGrid, PolarAngleAxis, Radar, AreaChart, Area, XAxis, YAxis, CartesianGrid } from 'recharts';

// Mock data para análisis
const audienceData = [
  { name: '18-24', value: 25, color: '#a78bfa' },
  { name: '25-34', value: 35, color: '#60a5fa' },
  { name: '35-44', value: 20, color: '#06b6d4' },
  { name: '45-54', value: 12, color: '#84cc16' },
  { name: '55+', value: 8, color: '#f97316' },
];

const platformData = [
  { platform: 'Instagram', engagement: 85, reach: 92, growth: 78 },
  { platform: 'Twitter', engagement: 70, reach: 75, growth: 68 },
  { platform: 'Facebook', engagement: 65, reach: 80, growth: 60 },
  { platform: 'TikTok', engagement: 95, reach: 88, growth: 92 },
  { platform: 'LinkedIn', engagement: 60, reach: 65, growth: 55 },
];

const monthlyGrowth = [
  { month: 'Ene', followers: 15000, engagement: 12000 },
  { month: 'Feb', followers: 18000, engagement: 15000 },
  { month: 'Mar', followers: 22000, engagement: 19000 },
  { month: 'Abr', followers: 25000, engagement: 21000 },
  { month: 'May', followers: 28000, engagement: 24000 },
  { month: 'Jun', followers: 31000, engagement: 27000 },
];

const genderData = [
  { name: 'Femenino', value: 52, color: '#ec4899' },
  { name: 'Masculino', value: 45, color: '#3b82f6' },
  { name: 'Otro', value: 3, color: '#8b5cf6' },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      {/* Top Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-white/95">Análisis Detallado</h2>
          <p className="text-sm text-white/50 mt-1">Métricas completas de rendimiento</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl backdrop-blur-xl bg-white/[0.08] border border-white/20 text-sm font-medium text-white/90 hover:bg-white/[0.12] transition-all">
            <Calendar className="w-4 h-4" />
            Últimos 30 días
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#a78bfa] to-[#3b82f6] text-sm font-medium text-white shadow-[0_0_20px_rgba(147,51,234,0.4)] hover:shadow-[0_0_30px_rgba(147,51,234,0.6)] transition-all">
            <Download className="w-4 h-4" />
            Exportar Reporte
          </button>
        </div>
      </div>

      {/* Crecimiento mensual */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_20px_rgba(6,182,212,0.4)]">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-white/95">Crecimiento Mensual</h2>
        </div>

        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={monthlyGrowth}>
            <defs>
              <linearGradient id="followersGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#a78bfa" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.1} />
              </linearGradient>
              <linearGradient id="engagementGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#84cc16" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis 
              dataKey="month" 
              stroke="rgba(255,255,255,0.4)" 
              tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis 
              stroke="rgba(255,255,255,0.4)" 
              tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '12px',
                backdropFilter: 'blur(20px)',
                color: '#fff',
                fontSize: '12px',
              }}
            />
            <Area
              type="monotone"
              dataKey="followers"
              stroke="#a78bfa"
              strokeWidth={3}
              fill="url(#followersGradient)"
              name="Seguidores"
            />
            <Area
              type="monotone"
              dataKey="engagement"
              stroke="#06b6d4"
              strokeWidth={3}
              fill="url(#engagementGradient)"
              name="Engagement"
            />
          </AreaChart>
        </ResponsiveContainer>

        <div className="flex items-center justify-center gap-8 mt-5 pt-4 border-t border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_8px_rgba(167,139,250,0.5)]" />
            <span className="text-xs text-white/60">Seguidores</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_8px_rgba(6,182,212,0.5)]" />
            <span className="text-xs text-white/60">Engagement</span>
          </div>
        </div>
      </div>

      {/* Demographics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Edad */}
        <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_16px_rgba(167,139,250,0.4)]">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-base font-semibold text-white/95">Por Edad</h3>
          </div>

          <ResponsiveContainer width="100%" height={200}>
            <RechartsPie>
              <Pie
                data={audienceData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {audienceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(15, 23, 42, 0.95)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(20px)',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
            </RechartsPie>
          </ResponsiveContainer>

          <div className="space-y-2 mt-4">
            {audienceData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-white/60">{item.name} años</span>
                </div>
                <span className="font-medium text-white/90">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Género */}
        <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#ec4899] to-[#8b5cf6] shadow-[0_0_16px_rgba(236,72,153,0.4)]">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-base font-semibold text-white/95">Por Género</h3>
          </div>

          <ResponsiveContainer width="100%" height={200}>
            <RechartsPie>
              <Pie
                data={genderData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {genderData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(15, 23, 42, 0.95)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(20px)',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
            </RechartsPie>
          </ResponsiveContainer>

          <div className="space-y-2 mt-4">
            {genderData.map((item) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-white/60">{item.name}</span>
                </div>
                <span className="font-medium text-white/90">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance por plataforma (Radar) */}
        <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_16px_rgba(249,115,22,0.4)]">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-base font-semibold text-white/95">Plataformas</h3>
          </div>

          <ResponsiveContainer width="100%" height={200}>
            <RadarChart data={platformData}>
              <PolarGrid stroke="rgba(255,255,255,0.1)" />
              <PolarAngleAxis 
                dataKey="platform" 
                tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 10 }}
              />
              <Radar
                name="Engagement"
                dataKey="engagement"
                stroke="#a78bfa"
                fill="#a78bfa"
                fillOpacity={0.3}
              />
              <Radar
                name="Alcance"
                dataKey="reach"
                stroke="#06b6d4"
                fill="#06b6d4"
                fillOpacity={0.3}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(15, 23, 42, 0.95)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(20px)',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
            </RadarChart>
          </ResponsiveContainer>

          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#a78bfa]" />
              <span className="text-xs text-white/60">Engagement</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#06b6d4]" />
              <span className="text-xs text-white/60">Alcance</span>
            </div>
          </div>
        </div>
      </div>

      {/* Platform Performance Details */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_20px_rgba(147,51,234,0.4)]">
            <PieChart className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-white/95">Rendimiento por Plataforma</h2>
        </div>

        <div className="space-y-4">
          {platformData.map((platform, index) => (
            <div
              key={index}
              className="rounded-[20px] backdrop-blur-xl bg-gradient-to-br from-white/[0.08] to-white/[0.03] border border-white/10 p-5"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-base font-semibold text-white/95">{platform.platform}</span>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-xs text-white/50">Engagement</div>
                    <div className="text-sm font-semibold text-white/90">{platform.engagement}%</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-white/50">Alcance</div>
                    <div className="text-sm font-semibold text-white/90">{platform.reach}%</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-white/50">Crecimiento</div>
                    <div className="text-sm font-semibold text-[#4ade80]">+{platform.growth}%</div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="h-2 rounded-full bg-white/[0.05] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#a78bfa] to-[#3b82f6] rounded-full"
                    style={{ width: `${platform.engagement}%` }}
                  />
                </div>
                <div className="h-2 rounded-full bg-white/[0.05] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#06b6d4] to-[#84cc16] rounded-full"
                    style={{ width: `${platform.reach}%` }}
                  />
                </div>
                <div className="h-2 rounded-full bg-white/[0.05] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#f97316] to-[#ef4444] rounded-full"
                    style={{ width: `${platform.growth}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
