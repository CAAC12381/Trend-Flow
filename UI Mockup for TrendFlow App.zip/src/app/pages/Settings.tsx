import { Settings as SettingsIcon, User, Bell, Shield, Palette, Globe, CreditCard } from 'lucide-react';

export default function Settings() {
  const settingsSections = [
    {
      title: 'Perfil',
      icon: User,
      color: 'from-[#a78bfa] to-[#3b82f6]',
      items: [
        { label: 'Nombre de usuario', value: '@trendflow_user', type: 'text' },
        { label: 'Email', value: 'user@trendflow.com', type: 'email' },
        { label: 'Biografía', value: 'Analista de redes sociales apasionado', type: 'textarea' },
      ],
    },
    {
      title: 'Notificaciones',
      icon: Bell,
      color: 'from-[#f97316] to-[#ef4444]',
      items: [
        { label: 'Alertas de tendencias', value: true, type: 'toggle' },
        { label: 'Reportes semanales', value: true, type: 'toggle' },
        { label: 'Menciones', value: false, type: 'toggle' },
        { label: 'Nuevos seguidores', value: true, type: 'toggle' },
      ],
    },
    {
      title: 'Privacidad',
      icon: Shield,
      color: 'from-[#06b6d4] to-[#84cc16]',
      items: [
        { label: 'Perfil público', value: true, type: 'toggle' },
        { label: 'Mostrar estadísticas', value: false, type: 'toggle' },
        { label: 'Permitir mensajes', value: true, type: 'toggle' },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#ec4899] to-[#8b5cf6] border-4 border-white/20 shadow-[0_0_24px_rgba(236,72,153,0.4)]" />
            <div>
              <h2 className="text-2xl font-semibold text-white/95">Usuario Premium</h2>
              <p className="text-sm text-white/50 mt-1">user@trendflow.com</p>
            </div>
          </div>
          <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#a78bfa] to-[#3b82f6] text-sm font-medium text-white shadow-[0_0_20px_rgba(147,51,234,0.4)] hover:shadow-[0_0_30px_rgba(147,51,234,0.6)] transition-all">
            Editar Perfil
          </button>
        </div>
      </div>

      {/* Settings Sections */}
      {settingsSections.map((section, sectionIndex) => (
        <div
          key={sectionIndex}
          className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className={`p-2.5 rounded-xl bg-gradient-to-br ${section.color} shadow-[0_0_20px_rgba(147,51,234,0.4)]`}>
              <section.icon className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-white/95">{section.title}</h2>
          </div>

          <div className="space-y-4">
            {section.items.map((item, itemIndex) => (
              <div
                key={itemIndex}
                className="flex items-center justify-between p-4 rounded-[20px] backdrop-blur-xl bg-gradient-to-br from-white/[0.08] to-white/[0.03] border border-white/10"
              >
                <div>
                  <label className="text-sm font-medium text-white/95">{item.label}</label>
                  {item.type !== 'toggle' && (
                    <div className="text-xs text-white/50 mt-1">{item.value as string}</div>
                  )}
                </div>
                {item.type === 'toggle' ? (
                  <button
                    className={`relative w-12 h-6 rounded-full transition-all ${
                      item.value
                        ? 'bg-gradient-to-r from-[#a78bfa] to-[#3b82f6] shadow-[0_0_12px_rgba(147,51,234,0.4)]'
                        : 'bg-white/[0.1]'
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-all shadow-lg ${
                        item.value ? 'left-[26px]' : 'left-0.5'
                      }`}
                    />
                  </button>
                ) : (
                  <button className="px-4 py-2 rounded-lg backdrop-blur-xl bg-white/[0.05] border border-white/10 text-xs font-medium text-white/80 hover:bg-white/[0.1] transition-all">
                    Editar
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Additional Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)] hover:border-white/25 transition-all cursor-pointer group">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#ec4899] to-[#8b5cf6] shadow-[0_0_16px_rgba(236,72,153,0.4)] mb-4 w-fit">
            <Palette className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-base font-semibold text-white/95 mb-2">Tema</h3>
          <p className="text-xs text-white/50">Personaliza la apariencia</p>
        </div>

        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)] hover:border-white/25 transition-all cursor-pointer group">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_16px_rgba(6,182,212,0.4)] mb-4 w-fit">
            <Globe className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-base font-semibold text-white/95 mb-2">Idioma</h3>
          <p className="text-xs text-white/50">Español (España)</p>
        </div>

        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)] hover:border-white/25 transition-all cursor-pointer group">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_16px_rgba(249,115,22,0.4)] mb-4 w-fit">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-base font-semibold text-white/95 mb-2">Suscripción</h3>
          <p className="text-xs text-white/50">Plan Premium - Activo</p>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-red-500/[0.12] to-red-600/[0.06] border border-red-500/30 p-6 shadow-[0_8px_32px_rgba(239,68,68,0.2),inset_0_1px_0_rgba(255,255,255,0.05)]">
        <h2 className="text-xl font-semibold text-red-400 mb-4">Zona de Peligro</h2>
        <div className="space-y-3">
          <button className="w-full p-4 rounded-[20px] backdrop-blur-xl bg-white/[0.05] border border-red-500/20 text-sm font-medium text-red-400 hover:bg-red-500/[0.1] hover:border-red-500/40 transition-all text-left">
            Desactivar cuenta temporalmente
          </button>
          <button className="w-full p-4 rounded-[20px] backdrop-blur-xl bg-white/[0.05] border border-red-500/20 text-sm font-medium text-red-400 hover:bg-red-500/[0.1] hover:border-red-500/40 transition-all text-left">
            Eliminar cuenta permanentemente
          </button>
        </div>
      </div>
    </div>
  );
}
