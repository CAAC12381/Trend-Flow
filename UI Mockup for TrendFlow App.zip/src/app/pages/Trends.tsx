import { TrendingUp, Hash, ArrowUpRight, Flame, Zap, Sparkles } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts';

// Mock data para tendencias
const trendingTopics = [
  { 
    id: 1, 
    hashtag: '#TechInnovation', 
    posts: 12500, 
    growth: 245, 
    category: 'Tecnología',
    sparkline: [40, 55, 45, 70, 85, 100, 125],
    color: 'from-[#a78bfa] to-[#3b82f6]'
  },
  { 
    id: 2, 
    hashtag: '#SustainableLiving', 
    posts: 8900, 
    growth: 189, 
    category: 'Lifestyle',
    sparkline: [30, 45, 50, 60, 75, 85, 89],
    color: 'from-[#06b6d4] to-[#84cc16]'
  },
  { 
    id: 3, 
    hashtag: '#DigitalArt', 
    posts: 15200, 
    growth: 312, 
    category: 'Arte',
    sparkline: [50, 60, 75, 90, 110, 135, 152],
    color: 'from-[#ec4899] to-[#8b5cf6]'
  },
  { 
    id: 4, 
    hashtag: '#FitnessGoals', 
    posts: 7800, 
    growth: 156, 
    category: 'Salud',
    sparkline: [35, 40, 50, 55, 65, 72, 78],
    color: 'from-[#f97316] to-[#ef4444]'
  },
  { 
    id: 5, 
    hashtag: '#AIRevolution', 
    posts: 18500, 
    growth: 428, 
    category: 'Tecnología',
    sparkline: [60, 80, 95, 120, 145, 170, 185],
    color: 'from-[#a78bfa] to-[#3b82f6]'
  },
  { 
    id: 6, 
    hashtag: '#TravelDiaries', 
    posts: 6400, 
    growth: 98, 
    category: 'Viajes',
    sparkline: [25, 35, 40, 48, 55, 60, 64],
    color: 'from-[#06b6d4] to-[#84cc16]'
  },
];

const viralContent = [
  {
    id: 1,
    title: 'Tutorial: Diseño Futurista con Glassmorphism',
    author: '@designpro',
    engagement: 45200,
    icon: Flame,
    color: 'from-[#f97316] to-[#ef4444]'
  },
  {
    id: 2,
    title: 'Las mejores prácticas de IA en 2026',
    author: '@techguru',
    engagement: 38900,
    icon: Zap,
    color: 'from-[#a78bfa] to-[#3b82f6]'
  },
  {
    id: 3,
    title: 'Cómo crear contenido viral en redes sociales',
    author: '@socialmedia',
    engagement: 52100,
    icon: Sparkles,
    color: 'from-[#ec4899] to-[#8b5cf6]'
  },
];

export default function Trends() {
  return (
    <div className="space-y-6">
      {/* Header con estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_16px_rgba(249,115,22,0.4)]">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <span className="text-sm font-medium text-white/60">Tendencias Activas</span>
          </div>
          <div className="text-4xl font-bold text-white">127</div>
          <div className="text-xs text-[#4ade80] mt-2">+23 desde ayer</div>
        </div>

        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_16px_rgba(167,139,250,0.4)]">
              <Hash className="w-5 h-5 text-white" />
            </div>
            <span className="text-sm font-medium text-white/60">Hashtags Monitoreados</span>
          </div>
          <div className="text-4xl font-bold text-white">45</div>
          <div className="text-xs text-white/40 mt-2">En tu colección</div>
        </div>

        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_16px_rgba(6,182,212,0.4)]">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-sm font-medium text-white/60">Crecimiento Promedio</span>
          </div>
          <div className="text-4xl font-bold text-white">+186%</div>
          <div className="text-xs text-[#4ade80] mt-2">Mejorando constantemente</div>
        </div>
      </div>

      {/* Trending Topics */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_20px_rgba(147,51,234,0.4)]">
              <Hash className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-white/95">Temas Populares</h2>
          </div>
          <button className="px-4 py-2 rounded-xl backdrop-blur-xl bg-white/[0.08] border border-white/20 text-sm font-medium text-white/90 hover:bg-white/[0.12] transition-all">
            Ver todos
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {trendingTopics.map((topic) => (
            <div
              key={topic.id}
              className="group rounded-[20px] backdrop-blur-xl bg-gradient-to-br from-white/[0.08] to-white/[0.03] border border-white/10 p-5 hover:border-white/20 hover:from-white/[0.12] hover:to-white/[0.06] transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-1.5 rounded-lg bg-gradient-to-br ${topic.color} shadow-[0_0_12px_rgba(167,139,250,0.3)]`}>
                      <Hash className="w-4 h-4 text-white" />
                    </div>
                    <span className={`text-lg font-semibold bg-gradient-to-r ${topic.color} bg-clip-text text-transparent`}>
                      {topic.hashtag}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-white/50">
                    <span>{topic.posts.toLocaleString()} posts</span>
                    <span className="px-2 py-1 rounded-lg bg-white/[0.05]">{topic.category}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#4ade80]/10 border border-[#4ade80]/20">
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#4ade80]" />
                  <span className="text-xs font-medium text-[#4ade80]">+{topic.growth}%</span>
                </div>
              </div>

              <div className="h-12 mt-3">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={topic.sparkline.map((value, i) => ({ value }))}>
                    <defs>
                      <linearGradient id={`gradient-${topic.id}`} x1="0" y1="0" x2="1" y2="0">
                        {topic.color.includes('a78bfa') && (
                          <>
                            <stop offset="0%" stopColor="#a78bfa" />
                            <stop offset="100%" stopColor="#3b82f6" />
                          </>
                        )}
                        {topic.color.includes('06b6d4') && (
                          <>
                            <stop offset="0%" stopColor="#06b6d4" />
                            <stop offset="100%" stopColor="#84cc16" />
                          </>
                        )}
                        {topic.color.includes('ec4899') && (
                          <>
                            <stop offset="0%" stopColor="#ec4899" />
                            <stop offset="100%" stopColor="#8b5cf6" />
                          </>
                        )}
                        {topic.color.includes('f97316') && (
                          <>
                            <stop offset="0%" stopColor="#f97316" />
                            <stop offset="100%" stopColor="#ef4444" />
                          </>
                        )}
                      </linearGradient>
                    </defs>
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke={`url(#gradient-${topic.id})`}
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Viral Content */}
      <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_20px_rgba(249,115,22,0.4)]">
            <Flame className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-white/95">Contenido Viral</h2>
        </div>

        <div className="space-y-4">
          {viralContent.map((content, index) => (
            <div
              key={content.id}
              className="group rounded-[20px] backdrop-blur-xl bg-gradient-to-br from-white/[0.08] to-white/[0.03] border border-white/10 p-5 hover:border-white/20 hover:from-white/[0.12] hover:to-white/[0.06] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-white/[0.15] to-white/[0.05] border border-white/10">
                  <span className="text-xl font-bold bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] bg-clip-text text-transparent">
                    {index + 1}
                  </span>
                </div>
                <div className={`p-2.5 rounded-xl bg-gradient-to-br ${content.color} shadow-[0_0_16px_rgba(249,115,22,0.3)]`}>
                  <content.icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-base font-semibold text-white/95 mb-1">{content.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-white/50">
                    <span>{content.author}</span>
                    <span>•</span>
                    <span>{content.engagement.toLocaleString()} interacciones</span>
                  </div>
                </div>
                <ArrowUpRight className="w-5 h-5 text-white/40 group-hover:text-white/70 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
