import { TrendingUp, Eye, Heart, BarChart3, Users, MousePointerClick } from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';

// Mock data para los gráficos
const trendData = [
  { time: '10:00', value: 2400 },
  { time: '12:00', value: 3800 },
  { time: '14:00', value: 3200 },
  { time: '16:00', value: 4800 },
  { time: '18:00', value: 6200 },
  { time: '20:00', value: 7800 },
  { time: '22:00', value: 9200 },
];

const weeklyData = [
  { day: 'Lun', impressions: 4200, engagement: 3800, clicks: 2400 },
  { day: 'Mar', impressions: 5800, engagement: 4200, clicks: 3200 },
  { day: 'Mié', impressions: 7200, engagement: 6800, clicks: 4800 },
  { day: 'Jue', impressions: 6400, engagement: 5400, clicks: 3800 },
  { day: 'Vie', impressions: 8800, engagement: 7200, clicks: 5400 },
  { day: 'Sáb', impressions: 9200, engagement: 8200, clicks: 6200 },
  { day: 'Dom', impressions: 7800, engagement: 6400, clicks: 4600 },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Métricas principales en grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Impressions Card */}
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_16px_rgba(6,182,212,0.4)]">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-[#4ade80] flex items-center gap-1">
              +18%
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </span>
          </div>
          <div className="text-sm font-medium text-white/60 mb-1">Impresiones</div>
          <div className="text-4xl font-bold bg-gradient-to-br from-[#06b6d4] via-[#22d3ee] to-[#84cc16] bg-clip-text text-transparent">
            48.2K
          </div>
          <div className="text-xs text-white/40 mt-2">Esta semana</div>
        </div>

        {/* Engagement Card */}
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#ec4899] to-[#8b5cf6] shadow-[0_0_16px_rgba(236,72,153,0.4)]">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-[#4ade80] flex items-center gap-1">
              +24%
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </span>
          </div>
          <div className="text-sm font-medium text-white/60 mb-1">Engagement</div>
          <div className="text-4xl font-bold bg-gradient-to-br from-[#ec4899] via-[#a855f7] to-[#8b5cf6] bg-clip-text text-transparent">
            12.8K
          </div>
          <div className="text-xs text-white/40 mt-2">Esta semana</div>
        </div>

        {/* Followers Card */}
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_16px_rgba(167,139,250,0.4)]">
              <Users className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-[#4ade80] flex items-center gap-1">
              +12%
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </span>
          </div>
          <div className="text-sm font-medium text-white/60 mb-1">Seguidores</div>
          <div className="text-4xl font-bold bg-gradient-to-br from-[#a78bfa] via-[#60a5fa] to-[#3b82f6] bg-clip-text text-transparent">
            28.5K
          </div>
          <div className="text-xs text-white/40 mt-2">Total acumulado</div>
        </div>

        {/* Clicks Card */}
        <div className="rounded-[24px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.10] to-white/[0.04] border border-white/15 p-6 shadow-[0_8px_24px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.08)]">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_16px_rgba(249,115,22,0.4)]">
              <MousePointerClick className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-[#4ade80] flex items-center gap-1">
              +31%
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </span>
          </div>
          <div className="text-sm font-medium text-white/60 mb-1">Clicks</div>
          <div className="text-4xl font-bold bg-gradient-to-br from-[#f97316] via-[#fb923c] to-[#ef4444] bg-clip-text text-transparent">
            6.4K
          </div>
          <div className="text-xs text-white/40 mt-2">Esta semana</div>
        </div>
      </div>

      {/* Gráficos principales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tarjeta de Tendencia Destacada */}
        <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_20px_rgba(147,51,234,0.4)]">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-white/95">Tendencia Destacada</h2>
            </div>
            <span className="text-sm font-medium text-[#4ade80] flex items-center gap-1">
              +32%
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </span>
          </div>

          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a78bfa" stopOpacity={0.5} />
                  <stop offset="50%" stopColor="#60a5fa" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="trendLineGradient" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#a78bfa" />
                  <stop offset="50%" stopColor="#60a5fa" />
                  <stop offset="100%" stopColor="#3b82f6" />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis 
                dataKey="time" 
                stroke="rgba(255,255,255,0.4)" 
                tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(15, 23, 42, 0.95)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(20px)',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="url(#trendLineGradient)"
                strokeWidth={3}
                fill="url(#trendGradient)"
                animationDuration={2000}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Gráfico de Actividad Semanal */}
        <div className="rounded-[28px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_20px_rgba(249,115,22,0.4)]">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-white/95">Actividad Semanal</h2>
          </div>

          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={weeklyData} barGap={4}>
              <defs>
                <linearGradient id="purpleBlue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a78bfa" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.6} />
                </linearGradient>
                <linearGradient id="cyanLime" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#84cc16" stopOpacity={0.6} />
                </linearGradient>
                <linearGradient id="orangeRed" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f97316" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0.6} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis 
                dataKey="day" 
                stroke="rgba(255,255,255,0.4)" 
                tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(15, 23, 42, 0.95)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  backdropFilter: 'blur(20px)',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar 
                dataKey="impressions" 
                fill="url(#purpleBlue)" 
                radius={[8, 8, 0, 0]}
                style={{ filter: 'drop-shadow(0 0 8px rgba(167, 139, 250, 0.5))' }}
              />
              <Bar 
                dataKey="engagement" 
                fill="url(#cyanLime)" 
                radius={[8, 8, 0, 0]}
                style={{ filter: 'drop-shadow(0 0 8px rgba(6, 182, 212, 0.5))' }}
              />
              <Bar 
                dataKey="clicks" 
                fill="url(#orangeRed)" 
                radius={[8, 8, 0, 0]}
                style={{ filter: 'drop-shadow(0 0 8px rgba(249, 115, 22, 0.5))' }}
              />
            </BarChart>
          </ResponsiveContainer>

          {/* Leyenda personalizada */}
          <div className="flex items-center justify-center gap-6 mt-5 pt-4 border-t border-white/10">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_8px_rgba(167,139,250,0.5)]" />
              <span className="text-xs text-white/60">Impresiones</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-gradient-to-br from-[#06b6d4] to-[#84cc16] shadow-[0_0_8px_rgba(6,182,212,0.5)]" />
              <span className="text-xs text-white/60">Engagement</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-gradient-to-br from-[#f97316] to-[#ef4444] shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
              <span className="text-xs text-white/60">Clicks</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
