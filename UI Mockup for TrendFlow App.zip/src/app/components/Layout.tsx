import { NavLink, Outlet } from 'react-router';
import { BarChart3, TrendingUp, PieChart, Settings, Search, Bell } from 'lucide-react';

export function Layout() {
  const navItems = [
    { to: '/', icon: BarChart3, label: 'Dashboard' },
    { to: '/tendencias', icon: TrendingUp, label: 'Tendencias' },
    { to: '/analisis', icon: PieChart, label: 'Análisis' },
    { to: '/configuracion', icon: Settings, label: 'Configuración' },
  ];

  return (
    <div className="min-h-screen bg-[#050510] overflow-hidden flex">
      {/* Fondo con metal líquido abstracto */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[50%] bg-gradient-to-br from-[#2d4663]/30 via-[#1a2744]/20 to-transparent rounded-[100%] blur-[120px]" />
        <div className="absolute top-[30%] right-[-15%] w-[70%] h-[60%] bg-gradient-to-tl from-[#334155]/25 via-[#1e3a5f]/15 to-transparent rounded-[100%] blur-[140px]" />
        <div className="absolute bottom-[-10%] left-[20%] w-[50%] h-[40%] bg-gradient-to-tr from-[#3b4c6b]/20 via-[#1a2540]/10 to-transparent rounded-[100%] blur-[100px]" />
      </div>

      {/* Sidebar glassmorphism */}
      <aside className="w-72 relative z-10 p-6 flex flex-col">
        <div className="flex-1 rounded-[32px] backdrop-blur-2xl bg-gradient-to-br from-white/[0.12] to-white/[0.06] border border-white/20 p-6 shadow-[0_8px_32px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.1)]">
          {/* Logo */}
          <div className="mb-10">
            <h1 className="text-2xl font-light text-white tracking-tight">
              <span className="font-semibold bg-gradient-to-r from-[#a78bfa] via-[#60a5fa] to-[#3b82f6] bg-clip-text text-transparent">
                TrendFlow
              </span>
            </h1>
            <p className="text-xs text-white/50 mt-1">Social Analytics Platform</p>
          </div>

          {/* Navigation */}
          <nav className="space-y-2 flex-1">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all group ${
                    isActive
                      ? 'bg-gradient-to-r from-[#a78bfa]/20 to-[#3b82f6]/20 border border-[#a78bfa]/30 shadow-[0_0_20px_rgba(147,51,234,0.3)]'
                      : 'hover:bg-white/[0.05] border border-transparent'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <div
                      className={`p-2 rounded-xl transition-all ${
                        isActive
                          ? 'bg-gradient-to-br from-[#a78bfa] to-[#3b82f6] shadow-[0_0_16px_rgba(147,51,234,0.4)]'
                          : 'bg-white/[0.05] group-hover:bg-white/[0.1]'
                      }`}
                    >
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <span
                      className={`font-medium ${
                        isActive ? 'text-white' : 'text-white/60 group-hover:text-white/80'
                      }`}
                    >
                      {item.label}
                    </span>
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* User profile at bottom */}
          <div className="mt-auto pt-6 border-t border-white/10">
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/[0.05] hover:bg-white/[0.08] transition-all cursor-pointer">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#ec4899] to-[#8b5cf6] border-2 border-white/20 shadow-[0_0_16px_rgba(236,72,153,0.4)]" />
              <div className="flex-1">
                <div className="text-sm font-medium text-white/95">Usuario</div>
                <div className="text-xs text-white/50">Premium Plan</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content area */}
      <main className="flex-1 relative z-10 p-6 overflow-y-auto">
        {/* Top bar */}
        <header className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-light text-white tracking-tight">
              Bienvenido de vuelta
            </h2>
            <p className="text-sm text-white/50 mt-1">
              {new Date().toLocaleDateString('es-ES', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button className="w-12 h-12 rounded-full backdrop-blur-xl bg-white/[0.08] border border-white/20 flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.15)] hover:shadow-[0_0_30px_rgba(168,85,247,0.3)] transition-all">
              <Search className="w-5 h-5 text-white/90" />
            </button>
            <button className="w-12 h-12 rounded-full backdrop-blur-xl bg-white/[0.08] border border-white/20 flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.15)] hover:shadow-[0_0_30px_rgba(168,85,247,0.3)] transition-all relative">
              <Bell className="w-5 h-5 text-white/90" />
              <div className="absolute top-2 right-2 w-2.5 h-2.5 bg-gradient-to-br from-[#f97316] to-[#ef4444] rounded-full shadow-[0_0_8px_rgba(239,68,68,0.6)]" />
            </button>
          </div>
        </header>

        {/* Page content */}
        <Outlet />
      </main>
    </div>
  );
}
