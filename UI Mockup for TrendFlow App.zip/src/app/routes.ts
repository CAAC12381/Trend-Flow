import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import Dashboard from './pages/Dashboard';
import Trends from './pages/Trends';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: 'tendencias', Component: Trends },
      { path: 'analisis', Component: Analytics },
      { path: 'configuracion', Component: Settings },
      { path: '*', Component: NotFound },
    ],
  },
]);