
  # UI Mockup for TrendFlow App

  This is a code bundle for UI Mockup for TrendFlow App. The original project is available at https://www.figma.com/design/EzsxzTKQd6XTMFIYFgECzT/UI-Mockup-for-TrendFlow-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  